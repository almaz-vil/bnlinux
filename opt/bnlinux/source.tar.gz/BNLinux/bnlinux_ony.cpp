/*
Поляков Дмитрий Владимирович <almaz-vil@list.ru>
25.01.2021
*/
/*
Поляков Дмитрий Владимирович <almaz-vil@list.ru>
25.01.2021
*/
#include "bnlinux_ony.h"




bnlinux_ony::bnlinux_ony()
{    
    
}

bnlinux_ony::~bnlinux_ony()
{    
}

void bnlinux_ony::Print(int key_char, Lang lang){
	

}