/*
Поляков Дмитрий Владимирович <almaz-vil@list.ru>
25.01.2021
*/
//**********************************
// * Реакция на знаки припенания
//************************************

#include "znaki_ony.h"

#ifndef TYPEE
#include "typee.h"
#endif

using namespace std;

Znak_ony::Znak_ony(){
}

Znak_ony::~Znak_ony(){    
}

void Znak_ony::Probel(){
}

void Znak_ony::obrabotka(int chr, Clovo *clovo){

}

//**Большая буква 
void Znak_ony::Uppad(Clovo *clovo){
    
 
}
/*Не ставим большую букв*/
void Znak_ony::BolBukvaClear(){}
/*Нет пробела*/
void Znak_ony::ProbelClear(){}