/*
Поляков Дмитрий Владимирович <almaz-vil@list.ru>
10.03.2021
*/

#ifndef BNLINUX_ONY
#include "bnlinux_ony.h"
#endif



bnlinux_ony::bnlinux_ony()
{    
    
}

bnlinux_ony::~bnlinux_ony()
{    
}

void bnlinux_ony::Print(int key_char, Lang lang){
	

}