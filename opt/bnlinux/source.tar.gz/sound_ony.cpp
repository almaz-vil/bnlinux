/*
Поляков Дмитрий Владимирович <almaz-vil@list.ru>
10.03.2021
*/
//*********************
//**Звуковая клавиатура
//*********************

#include <string.h>
#include <fstream>

#ifndef SOUND_ONY
#include "sound_ony.h"
#endif

#ifndef TYPEE
#include "typee.h"
#endif

Sound_ony::Sound_ony()
{
}


void Sound_ony::play(int n, Lang lang){

}