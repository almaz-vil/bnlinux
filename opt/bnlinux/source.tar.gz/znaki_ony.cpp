/*
Поляков Дмитрий Владимирович <almaz-vil@list.ru>
10.03.2021
*/
//**********************************
// * Реакция на знаки припенания
//************************************
#ifndef ZNAK_ONY
#include "znaki_ony.h"
#endif

#ifndef TYPEE
#include "typee.h"
#endif

using namespace std;

Znak_ony::Znak_ony(){
}

Znak_ony::~Znak_ony(){    
}

void Znak_ony::Probel(){
}

void Znak_ony::obrabotka(int chr, Clovo *clovo){

}

//**Большая буква 
void Znak_ony::Uppad(Clovo *clovo){
    
 
}
/*Не ставим большую букв*/
void Znak_ony::BolBukvaClear(){}
/*Нет пробела*/
void Znak_ony::ProbelClear(){}